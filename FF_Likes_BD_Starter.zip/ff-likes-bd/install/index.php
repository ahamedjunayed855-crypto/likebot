<?php
declare(strict_types=1);
session_start();
$root=dirname(__DIR__);$lock=__DIR__.'/.lock';$error='';$done=false;
if(is_file($lock)){$done=true;}
if(!$done && $_SERVER['REQUEST_METHOD']==='POST'){
 $host=trim($_POST['host']??'');$name=trim($_POST['name']??'');$user=trim($_POST['user']??'');$pass=(string)($_POST['pass']??'');$site=trim($_POST['site']??'FF Likes BD');
 try{
  if(!preg_match('/^[a-zA-Z0-9_]+$/',$name))throw new RuntimeException('Database name may contain letters, numbers and underscores only.');
  $pdo=new PDO('mysql:host='.$host.';charset=utf8mb4',$user,$pass,[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,PDO::ATTR_EMULATE_PREPARES=>false]);
  $pdo->exec('CREATE DATABASE IF NOT EXISTS `'.$name.'` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci');
  $pdo->exec('USE `'.$name.'`');
  $schema=file_get_contents(__DIR__.'/schema.sql');
  foreach(preg_split('/;\s*(?:\r?\n|$)/',$schema) as $sql){$sql=trim($sql);if($sql!=='')$pdo->exec($sql);}
  $seed=file_get_contents(__DIR__.'/seed.sql');
  foreach(preg_split('/;\s*(?:\r?\n|$)/',$seed) as $sql){$sql=trim($sql);if($sql!=='')$pdo->exec($sql);}
  $key=bin2hex(random_bytes(32));$cron=bin2hex(random_bytes(32));
  $config="<?php\nreturn ".var_export(['db'=>['host'=>$host,'name'=>$name,'user'=>$user,'pass'=>$pass],'app_key'=>$key,'cron_key'=>$cron,'site_name'=>$site],true).";\n";
  if(file_put_contents($root.'/config.php',$config,LOCK_EX)===false)throw new RuntimeException('Could not write config.php. Check permissions.');
  @chmod($root.'/config.php',0640);file_put_contents($lock,date(DATE_ATOM));@chmod($lock,0640);$done=true;
 }catch(Throwable $e){$error=$e->getMessage();}
}
?><!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>FF Likes BD Installer</title><style>body{font:16px system-ui;background:#f6f4ef;color:#1c1917;margin:0;padding:24px}.box{max-width:600px;margin:5vh auto;background:white;padding:24px;border:1px solid #e7e5e4;border-radius:16px}label{display:block;margin-top:12px}input{width:100%;padding:12px;border:1px solid #ccc;border-radius:8px;box-sizing:border-box}button{margin-top:18px;padding:13px 18px;background:#e8a317;border:0;border-radius:10px;font-weight:bold}.err{color:#b91c1c;white-space:pre-wrap}</style><div class="box"><h1>FF Likes BD · Installer</h1><?php if($done):?><h2>Database setup complete</h2><p>Seed data is installed. Delete the <code>install</code> directory now, keep config.php private, and configure HTTPS before public use.</p><p>Google login, payment gateway and delivery providers remain disabled until credentials and verified endpoints are configured.</p><?php else:?><p>PHP 8.2+, pdo_mysql and writable project root are required.</p><?php if($error):?><p class="err"><?=htmlspecialchars($error,ENT_QUOTES,'UTF-8')?></p><?php endif?><form method="post"><label>Database host<input name="host" value="localhost" required></label><label>Database name<input name="name" required></label><label>Database username<input name="user" required></label><label>Database password<input name="pass" type="password"></label><label>Site name<input name="site" value="FF Likes BD" required></label><button>Test connection & install</button></form><?php endif?></div></html>
