<?php
namespace App\Core;
use PDO;
final class DB {
 private static ?PDO $pdo=null;
 public static function connection(): PDO {
  if (self::$pdo) return self::$pdo;
  $f=dirname(__DIR__,2).'/config.php';
  if (!is_file($f)) throw new \RuntimeException('Configuration missing');
  $c=require $f;
  self::$pdo=new PDO('mysql:host='.$c['db']['host'].';dbname='.$c['db']['name'].';charset=utf8mb4',$c['db']['user'],$c['db']['pass'],[
   PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,
   PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC,
   PDO::ATTR_EMULATE_PREPARES=>false,
   PDO::ATTR_STRINGIFY_FETCHES=>false,
  ]);
  self::$pdo->exec("SET time_zone = '+06:00'");
  return self::$pdo;
 }
}
