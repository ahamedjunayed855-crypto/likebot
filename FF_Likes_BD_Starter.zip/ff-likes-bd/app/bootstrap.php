<?php
declare(strict_types=1);
date_default_timezone_set('Asia/Dhaka');
ini_set('display_errors','0');
error_reporting(E_ALL);
if (session_status() !== PHP_SESSION_ACTIVE) {
  session_name('fflikes_user');
  session_set_cookie_params(['lifetime'=>0,'path'=>'/','secure'=>(!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS']!=='off'),'httponly'=>true,'samesite'=>'Lax']);
  session_start();
}
spl_autoload_register(function(string $class): void {
 $prefix='App\\'; if (!str_starts_with($class,$prefix)) return;
 $file=__DIR__.'/'.str_replace('\\','/',substr($class,strlen($prefix))).'.php';
 if (is_file($file)) require $file;
});
