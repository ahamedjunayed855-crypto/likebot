# Manual test checklist

This starter is not a full production implementation. Use a staging site and a test database.

- [ ] Installer refuses a second run after `install/.lock` exists.
- [ ] config.php is not downloadable through HTTP.
- [ ] Product prices are loaded from the database, never from browser-submitted price values.
- [ ] Google OAuth state, nonce, PKCE and ID token validation are implemented before enabling login.
- [ ] UID name check is verified server-side before order confirmation.
- [ ] Double submit produces one order and one debit after OrderService is implemented.
- [ ] Manual deposit duplicate TrxID is rejected; credit only after admin approval.
- [ ] Nagorik return never credits without server-to-server verification and exact amount match.
- [ ] Invalid and stale webhook signatures are rejected.
- [ ] Provider SSRF protections and response size/time limits are tested.
- [ ] Refund routine is idempotent and writes ledger/history.
- [ ] API key, per-user filtering, IP allowlist and sliding-window limit are tested.
- [ ] Admin role permissions are enforced in every controller.
- [ ] Run `php tests/run.php` for the included utility smoke tests.
