<?php
declare(strict_types=1);
$tests=0;$failed=0;
function check(bool $ok,string $name):void{global $tests,$failed;$tests++;if(!$ok){$failed++;fwrite(STDERR,"FAIL: $name\n");}else echo "PASS: $name\n";}
function paisa(string $amount): int { if(!preg_match('/^\d{1,10}(?:\.\d{1,2})?$/',$amount))throw new InvalidArgumentException();[$a,$b]=array_pad(explode('.',$amount,2),2,'');return ((int)$a)*100+(int)str_pad($b,2,'0'); }
check(paisa('25.00')===2500,'whole taka to paisa');check(paisa('12.5')===1250,'decimal rounding representation');check(paisa('0.01')===1,'one paisa');
$good='valid';check(hash_equals(hash_hmac('sha256','123.body','secret'),hash_hmac('sha256','123.body','secret')),'HMAC comparison positive');check(!hash_equals(hash_hmac('sha256','123.body','secret'),hash_hmac('sha256','bad.body','secret')),'HMAC comparison negative');
$input='<p>Safe</p><script>alert(1)</script><img src="javascript:alert(1)" onerror="alert(1)">';$clean=preg_replace('~<script\b[^>]*>.*?</script\s*>~is','',$input);$clean=preg_replace('/\s+on[a-z]+\s*=\s*("[^"]*"|\'[^\']*\'|[^\s>]+)/i','',$clean);$clean=preg_replace('/javascript\s*:/i','',$clean);check(!str_contains(strtolower($clean),'<script'),'script removed by test sanitizer');check(!str_contains(strtolower($clean),'onerror'),'event attribute removed by test sanitizer');check(!str_contains(strtolower($clean),'javascript:'),'javascript scheme removed by test sanitizer');
$css='body{color:red}@import url(https://bad);';$stripped=preg_replace('/@import\b[^;]*;?/i','',$css);check(!str_contains(strtolower($stripped),'@import'),'CSS import stripped');
check(round(100*(1-5/100),2)===95.0,'rank discount calculation');
$allowed=['pending'=>['processing','manual_pending','failed_submit'],'processing'=>['partial','completed','failed','refunded']];check(in_array('completed',$allowed['processing'],true),'valid state transition');check(!in_array('pending',$allowed['completed']??[],true),'invalid state transition rejected');
echo "\n$tests tests; $failed failed.\n";exit($failed?1:0);
