# FF Likes BD — PHP starter package

A new Bangladesh-oriented Free Fire likes shop starter using PHP 8.2, MySQL 8, PDO and Apache shared hosting. The package has a light Bangla-first storefront, database installer/seeds, a protected configuration file, basic security headers, product display, and a cron health runner.

## Important scope statement

This ZIP is a **starter build, not the complete production-ready system described in the original specification**. In particular, Google OAuth, staff/admin UI and permissions, UID provider integration, transactional order placement, manual deposits approval UI, Nagorik Pay verification/webhooks, Telegram notifications, reseller API, theme editor/rollback, uploads, and retry/refund cron jobs are not implemented in this package. Those operations intentionally do not claim success or credit money. Do not launch with real customer payments until those modules are implemented and independently tested.

## Requirements

- PHP 8.2+; extensions `pdo_mysql`, `curl`, `openssl`, `mbstring`, `json`; GD optional.
- MySQL 8 or compatible InnoDB database.
- Apache with `mod_rewrite`, HTTPS, and writable project root during installation.

## cPanel installation

1. Create a MySQL database and database user in cPanel (or allow the installer to create the database if privileges permit).
2. Upload and extract the ZIP into the intended document root.
3. Ensure `storage/` exists and is writable by PHP. The installer must be able to write `config.php`.
4. Visit `https://your-domain.example/install/` and enter the DB connection details.
5. Confirm the homepage displays the four seeded packages.
6. Delete the entire `install/` directory after setup. Keep `config.php` protected and outside public download paths.
7. Enable HTTPS and test that `/config.php` returns 403/404, `/health` returns JSON, and `/` displays the storefront.

## Cron

The included cron script currently performs a health check only; it does **not** expire payments, sync providers, or retry/refund orders.

Example after implementing the remaining jobs:

```cron
*/5 * * * * /usr/local/bin/php /home/USER/public_html/cli/cron.php --key=YOUR_CRON_KEY >/dev/null 2>&1
```

The installer-generated cron key is stored in `config.php`. Prefer CLI cron; do not expose the key in public URLs or shell history longer than necessary.

## Google OAuth setup (for the future OAuth module)

Create an OAuth client in Google Cloud Console, configure the exact authorized redirect URI for your domain, and store Client ID/Secret server-side only. This starter intentionally does not implement the callback or ID-token verification, so the login route returns a disabled message.

## Payment and provider setup

No real gateway key or provider credentials are shipped. Before enabling payments, implement server-side Nagorik Pay create/verify calls, signature-checked webhook handling, transaction locking, exact amount verification, unique transaction IDs and idempotent ledger credit. A browser return URL is never proof of payment. Before enabling automatic delivery, configure a legitimate provider endpoint and validate its request/response contract, HTTPS/TLS, SSRF protection, timeouts and response-size limits. The current seeded packages are manual mode.

## Theme and logo

The starter storefront theme is in `assets/app.css` and uses CSS custom properties. A database-backed admin theme editor and logo upload are not included yet. Do not permit executable uploads; validate extension, MIME and decoded image data, use random filenames, and disable PHP execution in uploads.

## Tests

Run:

```bash
php tests/run.php
```

The included tests are utility smoke tests only; they are not a substitute for integration, concurrency, payment, OAuth, provider, authorization and security tests.

## Security checklist

- [ ] Set up HTTPS and secure cookies.
- [ ] Delete `install/` after installation.
- [ ] Back up the database and test restore.
- [ ] Do not put secrets in JavaScript, HTML, logs or public files.
- [ ] Use least-privilege database credentials.
- [ ] Implement admin password hashing, lockout, TOTP and server-side permission checks.
- [ ] Implement CSRF on every state-changing request.
- [ ] Add SSRF protection to admin-configured provider URLs.
- [ ] Verify gateway callbacks server-to-server; never trust client amounts.
- [ ] Test refund and credit idempotency under concurrent requests.
- [ ] Complete all checks in `tests/manual.md` before production.

## Troubleshooting

- **Blank page / HTTP 500:** inspect PHP-FPM/Apache logs; display_errors is intentionally disabled.
- **Installer cannot write config.php:** correct filesystem ownership/permissions; do not leave broad write permissions afterward.
- **Rewrite rules fail:** enable Apache `mod_rewrite`; test the host's `AllowOverride` setting.
- **Database connection fails:** verify database host, full cPanel-prefixed DB/user names and privileges.
- **cURL provider errors:** no provider requests are enabled in this starter; when implemented, verify DNS, TLS, timeout and provider contract.
