<?php
declare(strict_types=1);
$root=dirname(__DIR__);require $root.'/app/bootstrap.php';
$c=require $root.'/config.php';
$isCli=PHP_SAPI==='cli';$provided='';foreach($argv??[] as $arg)if(str_starts_with($arg,'--key='))$provided=substr($arg,6);if(!$isCli)$provided=$_GET['key']??'';
if(!is_string($provided)||!hash_equals((string)$c['cron_key'],$provided)){http_response_code(403);exit("Forbidden\n");}
if(!$isCli){header('Content-Type: text/plain; charset=utf-8');}
$lock=fopen($root.'/storage/cron.lock','c');if(!$lock||!flock($lock,LOCK_EX|LOCK_NB)){exit("Already running\n");}
try{$db=App\Core\DB::connection();$stmt=$db->prepare("INSERT INTO cron_runs(job_name,started_at,result,message) VALUES(?,NOW(),'success',?)");$stmt->execute(['health-check','Base cron runner completed; payment/order jobs are not enabled in this starter build.']);echo "Cron health check complete.\n";}catch(Throwable $e){error_log('Cron failure ref='.bin2hex(random_bytes(6)));http_response_code(500);echo "Cron failed; see server logs.\n";}flock($lock,LOCK_UN);fclose($lock);
