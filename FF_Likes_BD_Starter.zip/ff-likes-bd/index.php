<?php
declare(strict_types=1);
require __DIR__ . '/app/bootstrap.php';
use App\Core\DB;
use App\Core\Security;
Security::headers();
$path = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?: '/';
$base = rtrim(str_replace('index.php','', $_SERVER['SCRIPT_NAME'] ?? ''), '/');
if ($base !== '' && str_starts_with($path, $base)) $path = substr($path, strlen($base)) ?: '/';
if ($path === '/install' || str_starts_with($path, '/install/')) { header('Location: /install/'); exit; }
if ($path === '/health') { header('Content-Type: application/json'); echo json_encode(['ok'=>true,'app'=>'FF Likes BD']); exit; }
if ($path === '/auth/google') { http_response_code(503); echo 'Google OAuth is not configured. Set credentials in the secured admin settings after installation.'; exit; }
if ($path === '/order' && $_SERVER['REQUEST_METHOD']==='POST') {
  http_response_code(501); echo 'Order creation is disabled until a real player-info and like provider are configured.'; exit;
}
try {
 $db=DB::connection();
 $products=$db->query('SELECT id,slug,name_bn,name_en,type,likes_count,price,compare_price,short_bn,short_en,featured FROM products WHERE active=1 ORDER BY sort_order,id')->fetchAll();
} catch (Throwable $e) { http_response_code(503); echo '<!doctype html><meta charset="utf-8"><h1>Setup required</h1><p>Open <a href="/install/">the installer</a> to configure the database.</p>'; exit; }
$lang=($_GET['lang']??($_COOKIE['lang']??'bn'))==='en'?'en':'bn';
function h($s): string { return htmlspecialchars((string)$s, ENT_QUOTES|ENT_SUBSTITUTE, 'UTF-8'); }
function taka($n): string { $v=number_format((float)$n,2,'.',''); return '৳'.(str_ends_with($v,'.00')?substr($v,0,-3):$v); }
?><!doctype html><html lang="<?=h($lang)?>"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="theme-color" content="#E8A317"><title>FF Likes BD</title><link rel="stylesheet" href="/assets/app.css"></head><body>
<header class="top"><a class="brand" href="/">FF <span>Likes BD</span></a><nav><a href="/?lang=bn">বাংলা</a><a href="/?lang=en">EN</a><a class="login" href="/auth/google">Google Login</a></nav></header>
<main class="wrap"><section class="hero"><div class="eyebrow">SAFE • SIMPLE • BANGLADESH</div><h1><?=$lang==='bn'?'আপনার Free Fire Likes Shop':'Your Free Fire Likes Shop'?></h1><p><?=$lang==='bn'?'প্যাকেজ বেছে নিন, UID যাচাই করুন এবং নিরাপদ অর্ডার প্রক্রিয়া অনুসরণ করুন।':'Choose a package, verify your UID and follow a secure order flow.'?></p><a class="btn" href="#packages"><?=$lang==='bn'?'প্যাকেজ দেখুন':'Explore packages'?></a></section>
<section id="packages"><div class="section-head"><h2><?=$lang==='bn'?'লাইক প্যাকেজ':'Like packages'?></h2><span><?=count($products)?> packages</span></div><div class="grid"><?php foreach($products as $p): ?><article class="card"><div class="tile">♥</div><?php if($p['featured']):?><span class="chip">Popular</span><?php endif?><h3><?=h($lang==='bn'?$p['name_bn']:$p['name_en'])?></h3><p class="likes"><?=number_format((int)$p['likes_count'])?> Likes · <?=h(ucfirst($p['type']))?></p><p class="desc"><?=h($lang==='bn'?$p['short_bn']:$p['short_en'])?></p><div class="price"><?=taka($p['price'])?><?php if($p['compare_price']):?><del><?=taka($p['compare_price'])?></del><?php endif?></div><a class="btn full" href="/order?package=<?=(int)$p['id']?>"><?=$lang==='bn'?'অর্ডার করুন':'Order now'?></a></article><?php endforeach ?></div><?php if(!$products):?><p class="empty">No active packages yet. Add packages after signing in to the admin panel.</p><?php endif?></section>
<section class="notice"><h2><?=$lang==='bn'?'অর্ডার করার আগে':'Before ordering'?></h2><p><?=$lang==='bn'?'সঠিক UID দিন। প্রকৃত ডেলিভারি চালু করতে অ্যাডমিন প্যানেল থেকে যাচাইকৃত provider API কনফিগার করতে হবে।':'Enter the correct UID. A verified provider API must be configured by an administrator before real delivery can be enabled.'?></p></section></main><footer>© <?=date('Y')?> FF Likes BD · ৳ BDT</footer><script src="/assets/app.js" defer></script></body></html>
